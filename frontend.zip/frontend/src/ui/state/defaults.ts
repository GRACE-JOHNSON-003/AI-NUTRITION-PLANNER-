import type { FormState } from '../components/InputForm';

export function buildDefaultFormState(): FormState {
  return {
    age: 25,
    gender: 'male',
    heightCm: 175,
    weightKg: 72,
    activityLevel: 'moderate',
    goal: 'maintain',
    dietType: 'non_veg',
    allergies: ''
  };
}


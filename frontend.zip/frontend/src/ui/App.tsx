import { useEffect, useMemo, useRef, useState } from 'react';
import { InputForm, type FormState } from './components/InputForm';
import { ResultsDashboard } from './components/ResultsDashboard';
import { Plan47Page } from './components/Plan47Page';
import { buildDefaultFormState } from './state/defaults';
import { planApi, type NutritionPlanResult } from '../core/planApi';
import { BlastEffect } from './components/BlastEffect';

const INTRO_DELAY_MS = 1500;
const ACK_IMAGE_PRIMARY = '/ack47.png';
const ACK_IMAGE_FALLBACK = '/ack47-alt.png';
const PLAN47_PATH = '/plan-47';
const PLAN47_STORAGE_KEY = 'nutrition-plan-last-result';

export function App() {
  const [form, setForm] = useState<FormState>(() => buildDefaultFormState());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<NutritionPlanResult | null>(null);
  const [isTriggered, setIsTriggered] = useState(false);
  const [introDone, setIntroDone] = useState(false);
  const [view, setView] = useState<'dashboard' | 'plan47'>(() =>
    window.location.pathname === PLAN47_PATH ? 'plan47' : 'dashboard'
  );
  const timersRef = useRef<Array<number>>([]);

  const canSubmit = useMemo(() => {
    return form.age > 0 && form.heightCm > 0 && form.weightKg > 0;
  }, [form]);

  async function onSubmit() {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await planApi.generatePlan(form);
      setResult(data);
      saveResultForPlanPage(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to generate plan');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const handlePop = () => {
      setView(window.location.pathname === PLAN47_PATH ? 'plan47' : 'dashboard');
    };
    window.addEventListener('popstate', handlePop);

    if (window.location.pathname === PLAN47_PATH && !result) {
      const stored = loadResultForPlanPage();
      if (stored) setResult(stored);
    }

    return () => {
      window.removeEventListener('popstate', handlePop);
      for (const timer of timersRef.current) window.clearTimeout(timer);
    };
  }, [result]);

  function handleAcknowledgeClick() {
    if (isTriggered || introDone) return;
    setIsTriggered(true);

    const timer = window.setTimeout(() => {
      setIntroDone(true);
      setIsTriggered(false);
    }, INTRO_DELAY_MS);
    timersRef.current.push(timer);
  }

  function openPlan47Page() {
    if (!result) return;
    saveResultForPlanPage(result);
    window.history.pushState({}, '', PLAN47_PATH);
    setView('plan47');
  }

  function openDashboardPage() {
    window.history.pushState({}, '', '/');
    setView('dashboard');
  }

  return (
    <div className={`page ${isTriggered ? 'blastTriggered' : ''}`}>
      <BlastEffect active={isTriggered} />
      {!introDone ? (
        <AckGate
          isTriggered={isTriggered}
          imageSrc={ACK_IMAGE_PRIMARY}
          fallbackSrc={ACK_IMAGE_FALLBACK}
          onClick={handleAcknowledgeClick}
        />
      ) : view === 'plan47' ? (
        result ? (
          <Plan47Page result={result} onBack={openDashboardPage} />
        ) : (
          <div className="card">
            <h2>No plan data found</h2>
            <p className="muted">Generate a plan first, then open the 47-day page.</p>
            <button className="btn secondary" onClick={openDashboardPage}>
              Back to Dashboard
            </button>
          </div>
        )
      ) : (
        <>
      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden="true">
            <span>🥗</span>
          </div>
          <div>
            <div className="title">AI Nutrition Planner</div>
            <div className="subtitle">AI-powered personalized nutrition</div>
          </div>
        </div>
        <div className="topbarRight">
          <span className="statusBadge">
            <span className="statusDot" />
            AI Active
          </span>
          <a className="pill" href="/health" target="_blank" rel="noreferrer">
            API health
          </a>
        </div>
      </header>

      <main className="grid">
        <section className="card inputCard">
          <div className="cardHeader">
            <h2>Planner Inputs</h2>
            <span className="chip">Smart form</span>
          </div>
          <p className="muted">Enter your details to generate a realistic daily plan. No medical advice.</p>
          <InputForm value={form} onChange={setForm} />
          <div className="actions">
            <button className="btn generateBtn" onClick={onSubmit} disabled={!canSubmit || loading}>
              {loading ? (
                <>
                  <span className="spinner" />
                  Generating plan...
                </>
              ) : (
                'Generate plan'
              )}
            </button>
            <button
              className="btn secondary"
              onClick={() => {
                setForm(buildDefaultFormState());
                setResult(null);
                setError(null);
              }}
              disabled={loading}
            >
              Reset
            </button>
          </div>
          {error ? <div className="error">{error}</div> : null}
        </section>

        <section className="card resultsCard">
          <div className="cardHeader">
            <h2>Results Dashboard</h2>
            <span className="chip">Live analysis</span>
          </div>
          {loading ? (
            <LoadingState />
          ) : !result ? (
            <div className="placeholder">
              <div className="placeholderTitle">Your plan will appear here</div>
              <div className="muted">
                Tip: if you don’t set an API key, the backend returns a demo plan so you can still
                present the product.
              </div>
            </div>
          ) : (
            <ResultsDashboard result={result} onOpenPlan47={openPlan47Page} />
          )}
        </section>
      </main>

      <footer className="footer muted">
        Built for hackathons with clean modular architecture.
      </footer>
        </>
      )}
    </div>
  );
}

function saveResultForPlanPage(result: NutritionPlanResult) {
  try {
    window.sessionStorage.setItem(PLAN47_STORAGE_KEY, JSON.stringify(result));
  } catch {
    // no-op: non-blocking enhancement
  }
}

function loadResultForPlanPage(): NutritionPlanResult | null {
  try {
    const raw = window.sessionStorage.getItem(PLAN47_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as NutritionPlanResult;
  } catch {
    return null;
  }
}

function LoadingState() {
  return (
    <div className="loadingState">
      <div className="loadingPulse" />
      <div className="loadingText">Generating personalized plan with AI...</div>
    </div>
  );
}

function AckGate({
  isTriggered,
  imageSrc,
  fallbackSrc,
  onClick
}: {
  isTriggered: boolean;
  imageSrc: string;
  fallbackSrc: string;
  onClick: () => void;
}) {
  return (
    <div className={`ackGate ${isTriggered ? 'locked' : ''}`}>
      <button className="ackImageButton" onClick={onClick} disabled={isTriggered} aria-label="ACKNOWLEDGEMENT 47">
        <img
          className="ackImage"
          src={imageSrc}
          alt="ACKNOWLEDGEMENT 47"
          onError={(e) => {
            const img = e.currentTarget;
            if (img.src.endsWith(fallbackSrc)) return;
            img.src = fallbackSrc;
          }}
        />
        <div className="ackOverlayText">
          {isTriggered ? 'ACKNOWLEDGEMENT 47 • INITIATED' : 'CLICK TO ENTER • ACKNOWLEDGEMENT 47'}
        </div>
      </button>
    </div>
  );
}


export function parseMacroGrams(raw: string): number | null {
  const t = (raw ?? '').toLowerCase();
  const m = t.match(/(\d+(\.\d+)?)\s*g/);
  if (m?.[1]) return Math.round(Number(m[1]));
  const m2 = t.match(/(\d+(\.\d+)?)/);
  if (m2?.[1]) return Math.round(Number(m2[1]));
  return null;
}


import { parseMacroGrams } from './parseMacroGrams';

export function MacroBars({ protein, carbs, fats }: { protein: string; carbs: string; fats: string }) {
  const p = parseMacroGrams(protein);
  const c = parseMacroGrams(carbs);
  const f = parseMacroGrams(fats);

  const total = (p ?? 0) + (c ?? 0) + (f ?? 0);
  const pct = (x: number | null) => (total > 0 && x != null ? Math.round((x / total) * 100) : null);

  return (
    <div className="macroWrap">
      <MacroRow icon="💪" name="Protein" raw={protein} grams={p} pct={pct(p)} />
      <MacroRow icon="⚡" name="Carbs" raw={carbs} grams={c} pct={pct(c)} />
      <MacroRow icon="🥑" name="Fats" raw={fats} grams={f} pct={pct(f)} />
    </div>
  );
}

function MacroRow({
  icon,
  name,
  raw,
  grams,
  pct
}: {
  icon: string;
  name: string;
  raw: string;
  grams: number | null;
  pct: number | null;
}) {
  const width = pct == null ? 0 : pct;
  return (
    <div className="macroRow">
      <div className="macroLeft">
        <div className="macroName">
          <span>{icon}</span>
          <span>{name}</span>
        </div>
        <div className="muted macroRaw">{raw || '—'}</div>
      </div>
      <div className="macroBar">
        <div className="macroFill" style={{ width: `${width}%` }} />
      </div>
      <div className="macroRight muted">{pct != null ? `${pct}%` : grams != null ? `${grams}g` : '—'}</div>
    </div>
  );
}


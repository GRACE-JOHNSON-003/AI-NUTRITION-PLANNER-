import type { NutritionPlanResult } from '../../core/planApi';
import { parseMacroGrams } from './macro/parseMacroGrams';

type DayPlan = {
  day: number;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  breakfast: string;
  lunch: string;
  dinner: string;
  snacks: string;
  tip: string;
};

export function Plan47Page({
  result,
  onBack
}: {
  result: NutritionPlanResult;
  onBack: () => void;
}) {
  const plans = build47DayPlan(result);

  return (
    <div className="plan47Page">
      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden="true">
            <span>🥗</span>
          </div>
          <div>
            <div className="title">47-Day Nutrition Plan</div>
            <div className="subtitle">Generated from your current plan data</div>
          </div>
        </div>
        <button className="btn secondary" onClick={onBack}>
          Back to Dashboard
        </button>
      </header>

      <section className="card plan47Summary">
        <h2>Current Baseline</h2>
        <div className="muted">
          Goal: <strong>{prettyGoal(result.input.goal)}</strong> • Diet:{' '}
          <strong>{prettyDiet(result.input.dietType)}</strong> • Calories baseline:{' '}
          <strong>{result.computed.caloriesNeeded} kcal</strong>
        </div>
      </section>

      <section className="plan47List">
        {plans.map((p) => (
          <article key={p.day} className="card plan47Card">
            <div className="plan47CardHead">
              <h3>Day {p.day}</h3>
              <span className="chip">{p.calories} kcal</span>
            </div>

            <div className="plan47Macros">
              <span>Protein: {p.protein}g</span>
              <span>Carbs: {p.carbs}g</span>
              <span>Fats: {p.fats}g</span>
            </div>

            <div className="plan47Meals">
              <div><strong>Breakfast:</strong> {p.breakfast}</div>
              <div><strong>Lunch:</strong> {p.lunch}</div>
              <div><strong>Dinner:</strong> {p.dinner}</div>
              <div><strong>Snacks:</strong> {p.snacks}</div>
            </div>

            <div className="plan47Tip">Tip: {p.tip}</div>
          </article>
        ))}
      </section>
    </div>
  );
}

function build47DayPlan(result: NutritionPlanResult): DayPlan[] {
  const baseCalories = Math.max(1, result.computed.caloriesNeeded);
  const baseProtein = Math.max(1, parseMacroGrams(result.ai.nutritionalBreakdown.protein) ?? 120);
  const baseCarbs = Math.max(1, parseMacroGrams(result.ai.nutritionalBreakdown.carbs) ?? 220);
  const baseFats = Math.max(1, parseMacroGrams(result.ai.nutritionalBreakdown.fats) ?? 70);

  const breakfasts = variants(result.ai.mealPlan.breakfast);
  const lunches = variants(result.ai.mealPlan.lunch);
  const dinners = variants(result.ai.mealPlan.dinner);
  const snacks = variants(result.ai.mealPlan.snacks);
  const tips = result.ai.healthTips.length ? result.ai.healthTips : ['Stay consistent and hydrated daily.'];

  const plans: DayPlan[] = [];
  for (let day = 1; day <= 47; day++) {
    const offset = dailyOffset(result.input.goal, day);
    const macro = macroFactors(result.input.goal, day);

    plans.push({
      day,
      calories: Math.max(1, Math.round(baseCalories + offset)),
      protein: Math.max(1, Math.round(baseProtein * macro.protein)),
      carbs: Math.max(1, Math.round(baseCarbs * macro.carbs)),
      fats: Math.max(1, Math.round(baseFats * macro.fats)),
      breakfast: breakfasts[(day - 1) % breakfasts.length],
      lunch: lunches[(day - 1) % lunches.length],
      dinner: dinners[(day - 1) % dinners.length],
      snacks: snacks[(day - 1) % snacks.length],
      tip: tips[(day - 1) % tips.length]
    });
  }
  return plans;
}

function variants(base: string) {
  const clean = (base || 'Balanced meal option').trim();
  return [clean, `${clean} (portion-adjusted)`, `${clean} (high-fiber focus)`];
}

function dailyOffset(goal: NutritionPlanResult['input']['goal'], day: number) {
  if (goal === 'lose_weight') return -12 * (day - 1);
  if (goal === 'gain_muscle') return 10 * (day - 1);
  return 0;
}

function macroFactors(goal: NutritionPlanResult['input']['goal'], day: number) {
  const step = day - 1;
  if (goal === 'lose_weight') {
    return { protein: 1 + 0.0012 * step, carbs: 1 - 0.001 * step, fats: 1 - 0.0007 * step };
  }
  if (goal === 'gain_muscle') {
    return { protein: 1 + 0.0018 * step, carbs: 1 + 0.0014 * step, fats: 1 + 0.0008 * step };
  }
  return { protein: 1 + 0.0005 * step, carbs: 1 + 0.0004 * step, fats: 1 + 0.0002 * step };
}

function prettyGoal(goal: NutritionPlanResult['input']['goal']) {
  if (goal === 'lose_weight') return 'Lose weight';
  if (goal === 'gain_muscle') return 'Gain muscle';
  return 'Maintain';
}

function prettyDiet(diet: NutritionPlanResult['input']['dietType']) {
  return diet === 'non_veg' ? 'Non-veg' : diet;
}


import type { NutritionPlanResult } from '../../core/planApi';
import { MacroBars } from './macro/MacroBars';
import { TwoDayGraph } from './TwoDayGraph';

export function ResultsDashboard({
  result,
  onOpenPlan47
}: {
  result: NutritionPlanResult;
  onOpenPlan47: () => void;
}) {
  const { computed, ai, raw } = result;
  const bmiTone = getBmiTone(computed.bmiCategory);

  return (
    <div className="results">
      <div className="cards">
        <MiniCard
          icon="⚖️"
          title="BMI"
          value={`${computed.bmi}`}
          sub={`${computed.bmiCategory}`}
          tone={bmiTone}
        />
        <MiniCard
          icon="🔥"
          title="Calories"
          value={`${computed.caloriesNeeded} kcal`}
          sub={`TDEE ${computed.tdee} • BMR ${computed.bmr}`}
          tone="purple"
        />
      </div>

      <div className="section">
        <h3>AI Engine Status</h3>
        <div className={`aiExplain ${raw.llmMeta.source === 'mock_fallback' ? 'aiFallback' : 'aiLive'}`}>
          <div className="aiExplainTitle">
            {raw.llmMeta.source === 'openai'
              ? 'Live OpenAI Response'
              : raw.llmMeta.source === 'gemini'
                ? 'Live Gemini Response'
                : 'Fallback Demo Response'}
          </div>
          <div className="muted">{raw.llmMeta.explanation}</div>
          <details className="aiDetails">
            <summary>View full AI response explanation</summary>
            <pre className="aiRaw">{raw.llmText}</pre>
          </details>
        </div>
      </div>

      <div className="section">
        <h3>Meal plan</h3>
        <div className="mealGrid">
          <MealItem icon="☀️" title="Breakfast" text={ai.mealPlan.breakfast} />
          <MealItem icon="🍛" title="Lunch" text={ai.mealPlan.lunch} />
          <MealItem icon="🌙" title="Dinner" text={ai.mealPlan.dinner} />
          <MealItem icon="🍎" title="Snacks" text={ai.mealPlan.snacks} />
        </div>
      </div>

      <div className="section">
        <h3>Nutritional breakdown</h3>
        <MacroBars
          protein={ai.nutritionalBreakdown.protein}
          carbs={ai.nutritionalBreakdown.carbs}
          fats={ai.nutritionalBreakdown.fats}
        />
      </div>

      <div className="section">
        <h3>Day 1 to Day 47 Graph Layout</h3>
        <div className="day47Actions">
          <button className="btn day47Btn" onClick={onOpenPlan47}>
            Open Full 47-Day Plan Page
          </button>
        </div>
        <TwoDayGraph result={result} />
      </div>

      <div className="section">
        <h3>Health tips</h3>
        {ai.healthTips.length ? (
          <ul className="tipGrid">
            {ai.healthTips.map((t, i) => (
              <li key={i} className="tipCard">
                <span className="tipIcon">💡</span>
                <span>{t}</span>
              </li>
            ))}
          </ul>
        ) : (
          <div className="muted">No tips found in AI response.</div>
        )}
      </div>
    </div>
  );
}

function MiniCard({
  icon,
  title,
  value,
  sub,
  tone
}: {
  icon: string;
  title: string;
  value: string;
  sub: string;
  tone: 'green' | 'yellow' | 'red' | 'purple';
}) {
  return (
    <div className={`miniCard tone-${tone}`}>
      <div className="miniTitle">
        <span>{icon}</span>
        <span>{title}</span>
      </div>
      <div className="miniValue">{value}</div>
      <div className="miniSub muted">{sub}</div>
    </div>
  );
}

function MealItem({ icon, title, text }: { icon: string; title: string; text: string }) {
  return (
    <div className="mealItem">
      <div className="mealTitle">
        <span>{icon}</span>
        <span>{title}</span>
      </div>
      <div className="mealText">{text || '—'}</div>
    </div>
  );
}

function getBmiTone(category: NutritionPlanResult['computed']['bmiCategory']) {
  if (category === 'Normal') return 'green';
  if (category === 'Overweight') return 'yellow';
  if (category === 'Obese') return 'red';
  return 'yellow';
}


import type { ReactNode } from 'react';
import type { ActivityLevel, DietType, Gender, Goal } from '../../core/types';

export type FormState = {
  age: number;
  gender: Gender;
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: Goal;
  dietType: DietType;
  allergies: string;
};

export function InputForm({
  value,
  onChange
}: {
  value: FormState;
  onChange: (v: FormState) => void;
}) {
  return (
    <div className="form">
      <FormGroup title="Personal Info" icon="👤">
        <div className="row">
          <Field label="Age" icon="🎂">
            <input
              type="number"
              min={10}
              max={100}
              value={value.age}
              onChange={(e) => onChange({ ...value, age: Number(e.target.value) })}
            />
          </Field>
          <Field label="Gender" icon="⚧️">
            <select value={value.gender} onChange={(e) => onChange({ ...value, gender: e.target.value as Gender })}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </Field>
        </div>
      </FormGroup>

      <FormGroup title="Body Metrics" icon="📏">
        <div className="row">
          <Field label="Height (cm)" icon="📐">
            <input
              type="number"
              min={80}
              max={250}
              value={value.heightCm}
              onChange={(e) => onChange({ ...value, heightCm: Number(e.target.value) })}
            />
          </Field>
          <Field label="Weight (kg)" icon="⚖️">
            <input
              type="number"
              min={20}
              max={300}
              value={value.weightKg}
              onChange={(e) => onChange({ ...value, weightKg: Number(e.target.value) })}
            />
          </Field>
        </div>
      </FormGroup>

      <FormGroup title="Preferences" icon="🧠">
        <div className="row">
          <Field label="Activity" icon="🏃">
            <select
              value={value.activityLevel}
              onChange={(e) => onChange({ ...value, activityLevel: e.target.value as ActivityLevel })}
            >
              <option value="low">Low</option>
              <option value="moderate">Moderate</option>
              <option value="high">High</option>
            </select>
          </Field>
          <Field label="Goal" icon="🎯">
            <select value={value.goal} onChange={(e) => onChange({ ...value, goal: e.target.value as Goal })}>
              <option value="lose_weight">Lose weight</option>
              <option value="maintain">Maintain</option>
              <option value="gain_muscle">Gain muscle</option>
            </select>
          </Field>
        </div>

        <div className="row">
          <Field label="Diet type" icon="🥬">
            <select value={value.dietType} onChange={(e) => onChange({ ...value, dietType: e.target.value as DietType })}>
              <option value="veg">Veg</option>
              <option value="non_veg">Non-veg</option>
              <option value="vegan">Vegan</option>
            </select>
          </Field>
          <Field label="Allergies (optional)" icon="🚫">
            <input
              type="text"
              placeholder="e.g., peanuts, lactose"
              value={value.allergies}
              onChange={(e) => onChange({ ...value, allergies: e.target.value })}
            />
          </Field>
        </div>
      </FormGroup>
    </div>
  );
}

function FormGroup({ title, icon, children }: { title: string; icon: string; children: ReactNode }) {
  return (
    <section className="groupCard">
      <div className="groupTitle">
        <span>{icon}</span>
        <span>{title}</span>
      </div>
      {children}
    </section>
  );
}

function Field({ label, icon, children }: { label: string; icon: string; children: ReactNode }) {
  return (
    <label className="field">
      <div className="label">
        <span>{icon}</span>
        <span>{label}</span>
      </div>
      {children}
    </label>
  );
}


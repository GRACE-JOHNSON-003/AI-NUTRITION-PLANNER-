import { useEffect } from 'react';

export function BlastEffect({ active }: { active: boolean }) {
  useEffect(() => {
    if (!active) return;

    // Optional deterministic sound effect when browser audio APIs are available.
    try {
      const Ctx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(280, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(70, ctx.currentTime + 0.22);

      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.24);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);

      const timer = window.setTimeout(() => {
        void ctx.close();
      }, 320);

      return () => {
        window.clearTimeout(timer);
        void ctx.close();
      };
    } catch {
      return;
    }
  }, [active]);

  if (!active) return null;

  return (
    <div className="blastOverlay" aria-hidden="true">
      <div className="blastFlash" />
      <div className="blastGlow" />
      <div className="blastFade" />
    </div>
  );
}


import { parseMacroGrams } from './macro/parseMacroGrams';
import type { NutritionPlanResult } from '../../core/planApi';

export function TwoDayGraph({ result }: { result: NutritionPlanResult }) {
  const days = buildDays(result, 47);
  const maxCal = Math.max(...days.map((d) => d.metrics.calories), 1);
  const maxMacro = Math.max(
    ...days.flatMap((d) => [d.metrics.protein, d.metrics.carbs, d.metrics.fats]),
    1
  );

  return (
    <div className="dayGraphGrid">
      {days.map((day) => (
        <DayCard
          key={day.day}
          title={`Day ${day.day}`}
          day={day.metrics}
          maxCal={maxCal}
          maxMacro={maxMacro}
        />
      ))}
    </div>
  );
}

type DayMetrics = {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
};

function DayCard({
  title,
  day,
  maxCal,
  maxMacro
}: {
  title: string;
  day: DayMetrics;
  maxCal: number;
  maxMacro: number;
}) {
  return (
    <article className="dayCard">
      <div className="dayCardTitle">{title}</div>
      <MetricBar label="Calories" value={day.calories} max={maxCal} unit="kcal" />
      <MetricBar label="Protein" value={day.protein} max={maxMacro} unit="g" />
      <MetricBar label="Carbs" value={day.carbs} max={maxMacro} unit="g" />
      <MetricBar label="Fats" value={day.fats} max={maxMacro} unit="g" />
    </article>
  );
}

function MetricBar({
  label,
  value,
  max,
  unit
}: {
  label: string;
  value: number;
  max: number;
  unit: string;
}) {
  const width = Math.max(8, Math.round((value / max) * 100));
  return (
    <div className="dayMetricRow">
      <div className="dayMetricHead">
        <span>{label}</span>
        <span>{value} {unit}</span>
      </div>
      <div className="dayMetricTrack">
        <div className="dayMetricFill" style={{ width: `${width}%` }} />
      </div>
    </div>
  );
}

function buildDayOne(result: NutritionPlanResult): DayMetrics {
  return {
    calories: Math.max(1, result.computed.caloriesNeeded),
    protein: Math.max(1, parseMacroGrams(result.ai.nutritionalBreakdown.protein) ?? 120),
    carbs: Math.max(1, parseMacroGrams(result.ai.nutritionalBreakdown.carbs) ?? 220),
    fats: Math.max(1, parseMacroGrams(result.ai.nutritionalBreakdown.fats) ?? 70)
  };
}

function nextDay(result: NutritionPlanResult, previous: DayMetrics): DayMetrics {
  const goal = result.input.goal;
  // Fixed deterministic daily progression. No randomness.
  const calorieOffset = goal === 'lose_weight' ? -15 : goal === 'gain_muscle' ? 12 : 0;
  const proteinFactor = goal === 'gain_muscle' ? 1.003 : goal === 'lose_weight' ? 1.0015 : 1.001;
  const carbFactor = goal === 'lose_weight' ? 0.998 : goal === 'gain_muscle' ? 1.0018 : 1.0004;
  const fatFactor = goal === 'lose_weight' ? 0.9985 : goal === 'gain_muscle' ? 1.0012 : 1.0;

  return {
    calories: Math.max(1, Math.round(previous.calories + calorieOffset)),
    protein: Math.max(1, Math.round(previous.protein * proteinFactor)),
    carbs: Math.max(1, Math.round(previous.carbs * carbFactor)),
    fats: Math.max(1, Math.round(previous.fats * fatFactor))
  };
}

function buildDays(result: NutritionPlanResult, totalDays: number) {
  const days: Array<{ day: number; metrics: DayMetrics }> = [];
  let current = buildDayOne(result);
  days.push({ day: 1, metrics: current });

  for (let day = 2; day <= totalDays; day++) {
    current = nextDay(result, current);
    days.push({ day, metrics: current });
  }

  return days;
}


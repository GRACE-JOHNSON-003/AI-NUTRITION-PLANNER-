export type ActivityLevel = 'low' | 'moderate' | 'high';
export type Goal = 'lose_weight' | 'maintain' | 'gain_muscle';
export type DietType = 'veg' | 'non_veg' | 'vegan';
export type Gender = 'male' | 'female' | 'other';


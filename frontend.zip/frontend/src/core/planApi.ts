import type { ActivityLevel, DietType, Gender, Goal } from './types';

export type NutritionPlanInput = {
  age: number;
  gender: Gender;
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: Goal;
  dietType: DietType;
  allergies?: string;
};

export type NutritionPlanResult = {
  input: NutritionPlanInput;
  computed: {
    bmi: number;
    bmiCategory: 'Underweight' | 'Normal' | 'Overweight' | 'Obese';
    bmr: number;
    tdee: number;
    caloriesNeeded: number;
  };
  ai: {
    bmiText: string;
    caloriesNeededText: string;
    mealPlan: {
      breakfast: string;
      lunch: string;
      dinner: string;
      snacks: string;
    };
    nutritionalBreakdown: {
      protein: string;
      carbs: string;
      fats: string;
    };
    healthTips: string[];
  };
  raw: {
    llmText: string;
    llmMeta: {
      source: 'openai' | 'gemini' | 'mock_fallback';
      explanation: string;
    };
  };
};

export const planApi = {
  async generatePlan(input: NutritionPlanInput): Promise<NutritionPlanResult> {
    const resp = await fetch('/api/plan', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(input)
    });
    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      throw new Error(`API error (${resp.status}): ${text.slice(0, 200)}`);
    }
    return (await resp.json()) as NutritionPlanResult;
  }
};


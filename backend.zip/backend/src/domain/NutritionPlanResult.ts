import type { NutritionPlanInput } from './NutritionPlanInput.js';

export type ComputedMetrics = {
  bmi: number;
  bmiCategory: 'Underweight' | 'Normal' | 'Overweight' | 'Obese';
  bmr: number;
  tdee: number;
  caloriesNeeded: number;
};

export type AiMealPlan = {
  bmiText: string;
  caloriesNeededText: string;
  mealPlan: {
    breakfast: string;
    lunch: string;
    dinner: string;
    snacks: string;
  };
  nutritionalBreakdown: {
    protein: string;
    carbs: string;
    fats: string;
  };
  healthTips: string[];
};

export type NutritionPlanResult = {
  input: NutritionPlanInput;
  computed: ComputedMetrics;
  ai: AiMealPlan;
  raw: {
    llmText: string;
    llmMeta: {
      source: 'openai' | 'gemini' | 'mock_fallback';
      explanation: string;
    };
  };
};


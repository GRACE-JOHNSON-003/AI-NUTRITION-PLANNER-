import type { NutritionPlanInput } from '../NutritionPlanInput.js';

export class MasterPromptBuilder {
  static build(input: NutritionPlanInput & { bmi: number; caloriesNeeded: number }): string {
    const allergies = (input.allergies ?? '').trim() || 'None';

    // Keep the user's MASTER PROMPT verbatim (light mapping for enums).
    return `You are a certified professional nutritionist and diet planner.

Your task is to generate a personalized daily nutrition plan.

INPUT:
Age: ${input.age}
Gender: ${prettyGender(input.gender)}
Height: ${input.heightCm}
Weight: ${input.weightKg}
Activity Level: ${prettyActivity(input.activityLevel)}
Goal: ${prettyGoal(input.goal)}
Diet Type: ${prettyDiet(input.dietType)}
Allergies: ${allergies}

INSTRUCTIONS:

1. Calculate BMI
2. Estimate calories using BMR + activity
3. Adjust calories based on goal
4. Generate meal plan (Breakfast, Lunch, Dinner, Snacks)
5. Provide macros (Protein, Carbs, Fats)
6. Give practical health tips

OUTPUT FORMAT (STRICT):

BMI:
Calories Needed:
Meal Plan:

* Breakfast:
* Lunch:
* Dinner:
* Snacks:

Nutritional Breakdown:

* Protein:
* Carbs:
* Fats:

Health Tips:

* Tip 1
* Tip 2
* Tip 3

RULES:

* No medical advice
* Keep realistic
* Avoid extreme diets`;
  }
}

function prettyGender(g: NutritionPlanInput['gender']) {
  return g === 'male' ? 'Male' : g === 'female' ? 'Female' : 'Other';
}
function prettyActivity(a: NutritionPlanInput['activityLevel']) {
  return a === 'low' ? 'low' : a === 'moderate' ? 'moderate' : 'high';
}
function prettyGoal(g: NutritionPlanInput['goal']) {
  return g === 'lose_weight' ? 'lose weight' : g === 'maintain' ? 'maintain' : 'gain muscle';
}
function prettyDiet(d: NutritionPlanInput['dietType']) {
  return d === 'non_veg' ? 'non-veg' : d;
}


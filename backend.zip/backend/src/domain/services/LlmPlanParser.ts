import type { AiMealPlan } from '../NutritionPlanResult.js';

// "Simulated agent": MealPlanner + NutritionAnalyzer modules
// We keep parsing tolerant to minor LLM formatting drift while still mapping to strict fields.
export class LlmPlanParser {
  static parseStrict(text: string): AiMealPlan {
    const normalized = text.replace(/\r\n/g, '\n').trim();
    const plain = normalized.replace(/\*\*/g, '').replace(/^#{1,6}\s*/gm, '');

    const bmiText = firstPresent([
      pickValue(plain, /^BMI:\s*(.*)$/mi),
      extractBlockAfterHeader(plain, 'BMI')
    ]);
    const caloriesNeededText = firstPresent([
      pickValue(plain, /^Calories Needed:\s*(.*)$/mi),
      extractBlockAfterHeader(plain, 'Calories Needed')
    ]);

    const mealSection = extractSection(plain, 'Meal Plan', ['Nutritional Breakdown', 'Health Tips']);
    const breakfast = extractNamedBlock(mealSection, 'Breakfast');
    const lunch = extractNamedBlock(mealSection, 'Lunch');
    const dinner = extractNamedBlock(mealSection, 'Dinner');
    const snacks = extractNamedBlock(mealSection, 'Snacks');

    const nutritionSection = extractSection(plain, 'Nutritional Breakdown', ['Health Tips']);
    const protein = firstPresent([
      pickValue(nutritionSection, /^\*\s*Protein:\s*(.*)$/mi),
      pickValue(nutritionSection, /^-?\s*Total Protein:\s*(.*)$/mi),
      extractNamedBlock(nutritionSection, 'Protein')
    ]);
    const carbs = firstPresent([
      pickValue(nutritionSection, /^\*\s*Carbs:\s*(.*)$/mi),
      pickValue(nutritionSection, /^-?\s*Total Carbs:\s*(.*)$/mi),
      extractNamedBlock(nutritionSection, 'Carbs')
    ]);
    const fats = firstPresent([
      pickValue(nutritionSection, /^\*\s*Fats:\s*(.*)$/mi),
      pickValue(nutritionSection, /^-?\s*Total Fats:\s*(.*)$/mi),
      extractNamedBlock(nutritionSection, 'Fats')
    ]);

    const tipsSection = extractSection(plain, 'Health Tips', []);
    const healthTips = tipsSection
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.startsWith('*') || l.startsWith('-'))
      .map((l) => l.replace(/^[-*]\s*/, '').trim())
      .filter(Boolean)
      .slice(0, 10);

    return {
      bmiText: bmiText ?? '',
      caloriesNeededText: caloriesNeededText ?? '',
      mealPlan: {
        breakfast: breakfast ?? '',
        lunch: lunch ?? '',
        dinner: dinner ?? '',
        snacks: snacks ?? ''
      },
      nutritionalBreakdown: {
        protein: protein ?? '',
        carbs: carbs ?? '',
        fats: fats ?? ''
      },
      healthTips
    };
  }
}

function pickValue(text: string, re: RegExp) {
  const m = text.match(re);
  return sanitize(m?.[1]);
}

function firstPresent(values: Array<string | undefined>) {
  return values.find((v) => Boolean(v && v.trim().length > 0));
}

function extractBlockAfterHeader(text: string, header: string) {
  const body = extractSection(text, header, ['Meal Plan', 'Nutritional Breakdown', 'Health Tips']);
  const firstLine = body.split('\n').map((x) => x.trim()).find(Boolean);
  return sanitize(firstLine);
}

function extractSection(text: string, header: string, nextHeaders: string[]) {
  const headerRe = new RegExp(`^\\s*${escapeReg(header)}:\\s*$`, 'mi');
  const start = headerRe.exec(text);
  if (!start || start.index == null) return '';
  const sectionStart = start.index + start[0].length;
  const tail = text.slice(sectionStart);

  if (!nextHeaders.length) return tail.trim();

  const nextRe = new RegExp(`^\\s*(?:${nextHeaders.map(escapeReg).join('|')}):\\s*$`, 'mi');
  const next = nextRe.exec(tail);
  if (!next || next.index == null) return tail.trim();
  return tail.slice(0, next.index).trim();
}

function extractNamedBlock(sectionText: string, label: string) {
  if (!sectionText) return undefined;
  const lines = sectionText.split('\n');
  const labelRe = new RegExp(`^\\s*[-*]?\\s*${escapeReg(label)}\\s*:\\s*(.*)$`, 'i');
  const nextLabelRe = /^\s*[-*]?\s*(Breakfast|Lunch|Dinner|Snacks|Protein|Carbs|Fats)\s*:/i;

  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(labelRe);
    if (!m) continue;

    const chunks: string[] = [];
    const onLine = sanitize(m[1]);
    if (onLine) chunks.push(onLine);

    for (let j = i + 1; j < lines.length; j++) {
      const line = lines[j].trim();
      if (!line) continue;
      if (nextLabelRe.test(line)) break;
      chunks.push(line.replace(/^[-*]\s*/, ''));
    }

    return sanitize(chunks.join(' ').replace(/\s+/g, ' '));
  }

  return undefined;
}

function sanitize(value?: string) {
  if (!value) return undefined;
  const cleaned = value.replace(/\*\*/g, '').replace(/^#+\s*/, '').trim();
  return cleaned.length ? cleaned : undefined;
}

function escapeReg(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}


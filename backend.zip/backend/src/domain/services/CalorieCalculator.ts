import type { NutritionPlanInput } from '../NutritionPlanInput.js';
import type { ComputedMetrics } from '../NutritionPlanResult.js';

// "Simulated agent": CalorieCalculator module
export class CalorieCalculator {
  static calculate(input: NutritionPlanInput): ComputedMetrics {
    const heightM = input.heightCm / 100;
    const bmi = input.weightKg / (heightM * heightM);

    const bmiCategory: ComputedMetrics['bmiCategory'] =
      bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal' : bmi < 30 ? 'Overweight' : 'Obese';

    // Mifflin-St Jeor equation
    // For "other", use a midpoint constant to keep it simple and non-medical.
    const sexConstant = input.gender === 'male' ? 5 : input.gender === 'female' ? -161 : -78;
    const bmr = 10 * input.weightKg + 6.25 * input.heightCm - 5 * input.age + sexConstant;

    const activityFactor = input.activityLevel === 'low' ? 1.2 : input.activityLevel === 'moderate' ? 1.55 : 1.725;
    const tdee = bmr * activityFactor;

    const goalAdjustment =
      input.goal === 'lose_weight' ? -400 : input.goal === 'gain_muscle' ? 250 : 0;

    const caloriesNeeded = Math.max(1200, Math.round(tdee + goalAdjustment));

    return {
      bmi: round1(bmi),
      bmiCategory,
      bmr: Math.round(bmr),
      tdee: Math.round(tdee),
      caloriesNeeded
    };
  }
}

function round1(n: number) {
  return Math.round(n * 10) / 10;
}


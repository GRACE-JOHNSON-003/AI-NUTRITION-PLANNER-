import type { Request, Response } from 'express';

import { z } from 'zod';
import { GenerateNutritionPlanUseCase } from '../../usecases/GenerateNutritionPlanUseCase.js';
import { OpenAiChatCompletionsClient } from '../../infrastructure/llm/OpenAiChatCompletionsClient.js';
import { GeminiGenerativeClient } from '../../infrastructure/llm/GeminiGenerativeClient.js';
import { Env } from '../../infrastructure/config/Env.js';

const inputSchema = z.object({
  age: z.number().int().min(10).max(100),
  gender: z.enum(['male', 'female', 'other']),
  heightCm: z.number().min(80).max(250),
  weightKg: z.number().min(20).max(300),
  activityLevel: z.enum(['low', 'moderate', 'high']),
  goal: z.enum(['lose_weight', 'maintain', 'gain_muscle']),
  dietType: z.enum(['veg', 'non_veg', 'vegan']),
  allergies: z.string().max(2000).optional().default('')
});

export async function buildPlanController(req: Request, res: Response) {
  const parsed = inputSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: 'Invalid input',
      details: parsed.error.flatten()
    });
  }

  const llmClient =
    Env.llmProvider() === 'gemini'
      ? new GeminiGenerativeClient({
          apiKey: Env.geminiApiKey(),
          model: Env.geminiModel()
        })
      : new OpenAiChatCompletionsClient({
          apiKey: Env.openAiApiKey(),
          baseUrl: Env.openAiBaseUrl(),
          model: Env.openAiModel()
        });

  const useCase = new GenerateNutritionPlanUseCase(llmClient);

  try {
    const result = await useCase.execute(parsed.data);
    return res.json(result);
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Unknown error';
    return res.status(500).json({ error: 'Failed to generate plan', message });
  }
}


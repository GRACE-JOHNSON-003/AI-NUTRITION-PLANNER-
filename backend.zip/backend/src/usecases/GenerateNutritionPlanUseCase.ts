import type { NutritionPlanResult } from '../domain/NutritionPlanResult.js';
import type { NutritionPlanInput } from '../domain/NutritionPlanInput.js';
import { CalorieCalculator } from '../domain/services/CalorieCalculator.js';
import { MasterPromptBuilder } from '../domain/services/MasterPromptBuilder.js';
import { LlmPlanParser } from '../domain/services/LlmPlanParser.js';

import type { LlmClient } from './ports/LlmClient.js';

export class GenerateNutritionPlanUseCase {
  // Use-case layer: orchestrates domain logic + external LLM port.
  constructor(private readonly llm: LlmClient) {}

  async execute(input: NutritionPlanInput): Promise<NutritionPlanResult> {
    const metrics = CalorieCalculator.calculate(input);

    const prompt = MasterPromptBuilder.build({
      ...input,
      bmi: metrics.bmi,
      caloriesNeeded: metrics.caloriesNeeded
    });

    const llmOutput = await this.llm.generateText(prompt);
    const parsed = LlmPlanParser.parseStrict(llmOutput.text);

    return {
      input,
      computed: metrics,
      ai: parsed,
      raw: {
        llmText: llmOutput.text,
        llmMeta: {
          source: llmOutput.source,
          explanation: llmOutput.explanation
        }
      }
    };
  }
}


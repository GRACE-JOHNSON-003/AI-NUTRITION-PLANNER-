export type LlmGeneration = {
  text: string;
  source: 'openai' | 'gemini' | 'mock_fallback';
  explanation: string;
};

export type LlmClient = {
  generateText(prompt: string): Promise<LlmGeneration>;
};


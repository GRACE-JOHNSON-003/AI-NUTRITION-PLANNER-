export class Env {
  static llmProvider() {
    return (process.env.LLM_PROVIDER ?? 'openai').trim().toLowerCase();
  }

  static openAiApiKey() {
    return (process.env.OPENAI_API_KEY ?? '').trim();
  }
  static openAiBaseUrl() {
    return (process.env.OPENAI_BASE_URL ?? 'https://api.openai.com/v1').trim();
  }
  static openAiModel() {
    return (process.env.OPENAI_MODEL ?? 'gpt-4o-mini').trim();
  }

  static geminiApiKey() {
    return (process.env.GEMINI_API_KEY ?? '').trim();
  }

  static geminiModel() {
    return (process.env.GEMINI_MODEL ?? 'gemini-1.5-flash').trim();
  }
}

